const { storageGet, storageSet } = globalThis.ExtensionApiCompat || {};

if (!storageGet || !storageSet) {
  throw new Error("Extension API compatibility helpers are not available.");
}

const STORAGE_KEY = "settings";

const DEFAULT_PROFILE = {
  lastNameKanji: "",
  firstNameKanji: "",
  lastNameKana: "",
  firstNameKana: "",
  lastNameEnglish: "",
  firstNameEnglish: "",
  preferredName: "",
  email: "",
  mobileEmail: "",
  phone: "",
  gender: "",
  password: "",
  postalCode: "",
  prefecture: "",
  city: "",
  addressLine1: "",
  addressLine2: "",
  birthDate: "",
  university: "",
  educationType: "",
  universityKanaInitial: "",
  universityPrefecture: "",
  faculty: "",
  graduationYear: "",
  company: "",
  linkedIn: "",
  github: "",
  portfolio: "",
  note: ""
};

function hiraganaToKatakana(value) {
  return String(value || "")
    .normalize("NFKC")
    .replace(/[\u3041-\u3096]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) + 0x60));
}

function extractKatakanaCandidate(text) {
  const normalized = String(text || "").normalize("NFKC").trim();
  if (!normalized) return "";
  const katakana = hiraganaToKatakana(normalized);

  if (/[一-龯々〆ヵヶ]/.test(katakana)) return "";

  const onlyKana = katakana.replace(/[^ァ-ヴー]/g, "");
  if (!onlyKana) return "";
  return onlyKana;
}

function bindAutoFurigana(form) {
  const pairs = [
    { kanji: "lastNameKanji", kana: "lastNameKana" },
    { kanji: "firstNameKanji", kana: "firstNameKana" }
  ];

  for (const pair of pairs) {
    const kanjiInput = form.elements.namedItem(pair.kanji);
    const kanaInput = form.elements.namedItem(pair.kana);
    if (!(kanjiInput instanceof HTMLInputElement) || !(kanaInput instanceof HTMLInputElement)) continue;

    let isComposing = false;
    let lastCompositionKana = "";
    let manualKanaOverride = kanaInput.value.trim() !== "";

    const applyKana = (candidate) => {
      if (manualKanaOverride) return;
      const next = extractKatakanaCandidate(candidate);
      if (!next) return;
      kanaInput.value = next;
    };

    kanaInput.addEventListener("input", () => {
      manualKanaOverride = kanaInput.value.trim() !== "";
    });

    kanjiInput.addEventListener("compositionstart", () => {
      isComposing = true;
    });

    kanjiInput.addEventListener("compositionupdate", (event) => {
      const data = extractKatakanaCandidate(event.data || "");
      if (!data) return;
      lastCompositionKana = data;
      applyKana(data);
    });

    kanjiInput.addEventListener("compositionend", (event) => {
      isComposing = false;
      const data = extractKatakanaCandidate(event.data || "");
      if (data) {
        lastCompositionKana = data;
        applyKana(data);
        return;
      }
      if (lastCompositionKana) applyKana(lastCompositionKana);
    });

    kanjiInput.addEventListener("input", () => {
      if (isComposing) return;
      const directKana = extractKatakanaCandidate(kanjiInput.value);
      if (directKana) {
        applyKana(directKana);
        return;
      }
      if (!kanaInput.value.trim() && lastCompositionKana) {
        applyKana(lastCompositionKana);
      }
    });
  }
}

async function loadSettings() {
  const { settings } = await storageGet([STORAGE_KEY]);
  return settings || { enabled: true, profile: { ...DEFAULT_PROFILE } };
}

async function saveSettings(settings) {
  await storageSet({ [STORAGE_KEY]: settings });
}

function setStatus(message) {
  document.getElementById("status").textContent = message;
}

function fillForm(profile) {
  const form = document.getElementById("profileForm");
  Object.entries(DEFAULT_PROFILE).forEach(([key, fallback]) => {
    const field = form.elements.namedItem(key);
    if (!field) return;
    field.value = profile[key] ?? fallback;
  });
}

function readForm() {
  const form = document.getElementById("profileForm");
  const next = { ...DEFAULT_PROFILE };
  Object.keys(DEFAULT_PROFILE).forEach((key) => {
    const field = form.elements.namedItem(key);
    if (!field) return;
    next[key] = field.value.trim();
  });
  return next;
}

function download(filename, content) {
  const blob = new Blob([content], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

async function init() {
  const form = document.getElementById("profileForm");
  const resetBtn = document.getElementById("resetBtn");
  const exportBtn = document.getElementById("exportBtn");

  let settings = await loadSettings();
  fillForm(settings.profile || {});
  bindAutoFurigana(form);

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    settings = { ...settings, profile: readForm() };
    await saveSettings(settings);
    setStatus("保存しました");
  });

  resetBtn.addEventListener("click", async () => {
    settings = { ...settings, profile: { ...DEFAULT_PROFILE } };
    fillForm(settings.profile);
    await saveSettings(settings);
    setStatus("リセットしました");
  });

  exportBtn.addEventListener("click", () => {
    const payload = JSON.stringify(readForm(), null, 2);
    download("nihon-apply-profile.json", payload);
    setStatus("JSONを出力しました");
  });
}

init();
