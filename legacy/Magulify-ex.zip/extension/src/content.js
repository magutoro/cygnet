const { extensionApi, storageGet, storageSet, openOptionsPage } = globalThis.ExtensionApiCompat || {};

if (!extensionApi || !storageGet || !storageSet || !openOptionsPage) {
  throw new Error("Extension API compatibility helpers are not available.");
}

const STORAGE_KEY = "settings";

const NON_NAME_FIELD_PATTERNS = {
  email: [/mail/, /e-?mail/, /メール/],
  phone: [/tel/, /phone/, /電話/],
  postalCode: [/postal/, /post.?code/, /zip/, /〒/, /郵便/, /郵便番号/],
  prefecture: [/prefecture/, /都道府県/],
  city: [/city/, /市区町村/],
  addressLine1: [/\baddress\b/, /\baddress.?line.?1\b/, /住所/, /丁目|番地/],
  addressLine2: [/\baddress.?2\b/, /\baddress.?line.?2\b/, /building/, /マンション/, /アパート/, /建物/, /号室/],
  birthDate: [/birth/, /birthday/, /生年月日/],
  preferredName: [/preferred.?name/, /preffered.?name/, /希望名/, /通称/, /ニックネーム/],
  gender: [/gender/, /sex/, /性別/],
  password: [/password/, /passcode/, /パスワード/, /暗証/],
  educationType: [/学校区分/, /学歴区分/, /school.?type/, /education.?type/, /\bgkbn\b/],
  universityKanaInitial: [/学校名頭文字/, /頭文字/, /name.?initial/, /\bgon\b/],
  universityPrefecture: [/学校所在地/, /大学所在地/, /所在地.*都道府県/, /所在地.*検索対象/, /university.*prefecture/, /\bdken\b/],
  university: [/university/, /college/, /大学名/, /出身校/, /学校名/],
  faculty: [/faculty/, /学部/, /専攻/, /major/],
  graduationYear: [/graduation/, /卒業/, /year/],
  company: [/company/, /current.?employer/, /勤務先/, /会社/],
  linkedIn: [/linkedin/],
  github: [/github/],
  portfolio: [/portfolio/, /website/, /url/, /ブログ/],
  note: [/self.?pr/, /自己pr/, /志望動機/, /message/, /備考/, /cover.?letter/]
};

const FIELD_NEGATIVE_PATTERNS = {
  addressLine1: [/ゼミ/, /研究室/, /サークル/, /クラブ/, /趣味/, /資格/, /免許/, /志望/, /自己pr/],
  addressLine2: [/ゼミ/, /研究室/, /サークル/, /クラブ/, /趣味/, /資格/, /免許/, /志望/, /自己pr/]
};

const KANA_FIELD_KEYS = new Set(["lastNameKana", "firstNameKana"]);
const KANA_SCRIPT_KEYS = new Set(["kana", "hiragana", "katakana"]);
const AUTO_RUN_OBSERVE_MS = 15000;
const AUTO_RUN_DEBOUNCE_MS = 600;
const OVERLAY_HOST_ID = "magulify-inpage-overlay";
const OVERLAY_DOMAIN_STATE_KEY = "overlayDomainState";

const GENDER_VALUE_ALIASES = {
  male: ["male", "man", "m", "男性", "男", "男性（男）", "男性（man）"],
  female: ["female", "woman", "f", "女性", "女", "女性（女）", "女性（woman）"],
  non_binary: ["non binary", "non-binary", "x", "ノンバイナリー", "その他"],
  prefer_not_to_say: ["prefer not to say", "none", "無回答", "回答しない", "選択しない"],
  other: ["other", "others", "その他", "該当なし"]
};

const EDUCATION_TYPE_ALIASES = {
  university: ["university", "大学"],
  graduate_master: ["graduate school master", "master", "修士", "大学院（修士）", "大学院(修士)"],
  graduate_doctor: ["graduate school doctor", "doctor", "phd", "博士", "大学院（博士）", "大学院(博士)"],
  junior_college: ["junior college", "短期大学", "短大"],
  technical_college: ["technical college", "高等専門学校", "高専"],
  vocational: ["vocational school", "専門学校"],
  high_school: ["high school", "高校", "高等学校"],
  foreign_university_jp: ["foreign university japan", "外国大学日本校"],
  foreign_university: ["foreign university", "外国大学"]
};

const EDUCATION_TYPE_LABELS = {
  university: "大学",
  graduate_master: "大学院(修士)",
  graduate_doctor: "大学院(博士)",
  junior_college: "短期大学",
  technical_college: "高等専門学校",
  vocational: "専門学校",
  high_school: "高等学校",
  foreign_university_jp: "外国大学日本校",
  foreign_university: "外国大学"
};

const UNIVERSITY_READING_OVERRIDES = [
  { keywords: ["国際基督教大学", "icu", "internationalchristianuniversity"], reading: "こくさいきりすときょうだいがく" },
  { keywords: ["東京大学", "とうだい", "todai", "theuniversityoftokyo"], reading: "とうきょうだいがく" },
  { keywords: ["京都大学", "きょうだい", "kyotouniversity"], reading: "きょうとだいがく" },
  { keywords: ["早稲田大学", "waseda"], reading: "わせだだいがく" },
  { keywords: ["慶應義塾大学", "慶応義塾大学", "keio"], reading: "けいおうぎじゅくだいがく" },
  { keywords: ["上智大学", "sophia"], reading: "じょうちだいがく" },
  { keywords: ["一橋大学", "hitotsubashi"], reading: "ひとつばしだいがく" },
  { keywords: ["東北大学", "tohoku"], reading: "とうほくだいがく" },
  { keywords: ["北海道大学", "hokkaido", "hokudai"], reading: "ほっかいどうだいがく" },
  { keywords: ["大阪大学", "osaka", "handai"], reading: "おおさかだいがく" },
  { keywords: ["名古屋大学", "nagoya"], reading: "なごやだいがく" },
  { keywords: ["九州大学", "kyushu"], reading: "きゅうしゅうだいがく" },
  { keywords: ["神戸大学", "kobe"], reading: "こうべだいがく" },
  { keywords: ["筑波大学", "tsukuba"], reading: "つくばだいがく" },
  { keywords: ["東京科学大学", "東京工業大学", "tokyotech"], reading: "とうきょうかがくだいがく" },
  { keywords: ["工学院大学", "kogakuin"], reading: "こうがくいんだいがく" },
  { keywords: ["国学院大学", "kokugakuin"], reading: "こくがくいんだいがく" },
  { keywords: ["国士舘大学", "kokushikan"], reading: "こくしかんだいがく" },
  { keywords: ["駒澤大学", "駒沢大学", "komazawa"], reading: "こまざわだいがく" },
  { keywords: ["駒澤女子大学", "駒沢女子大学", "komazawajoshi"], reading: "こまざわじょしだいがく" },
  { keywords: ["国際医療福祉大学", "iuhw"], reading: "こくさいいりょうふくしだいがく" },
  { keywords: ["国際仏教学大学院大学"], reading: "こくさいぶっきょうがくだいがくいんだいがく" },
  { keywords: ["こども教育宝仙大学"], reading: "こどもきょういくほうせんだいがく" },
  { keywords: ["航空保安大学校"], reading: "こうくうほあんだいがっこう" },
  { keywords: ["国際ファッション専門職大学"], reading: "こくさいふぁっしょんせんもんしょくだいがく" },
  { keywords: ["国立看護大学校"], reading: "こくりつかんごだいがっこう" }
];

const GOJUON_INITIAL_MAP = {
  ぁ: "あ",
  ぃ: "い",
  ぅ: "う",
  ぇ: "え",
  ぉ: "お",
  ゃ: "や",
  ゅ: "ゆ",
  ょ: "よ",
  ゎ: "わ",
  ゕ: "か",
  ゖ: "け",
  ゐ: "い",
  ゑ: "え",
  ゔ: "う",
  が: "か",
  ぎ: "き",
  ぐ: "く",
  げ: "け",
  ご: "こ",
  ざ: "さ",
  じ: "し",
  ず: "す",
  ぜ: "せ",
  ぞ: "そ",
  だ: "た",
  ぢ: "ち",
  づ: "つ",
  で: "て",
  ど: "と",
  ば: "は",
  び: "ひ",
  ぶ: "ふ",
  べ: "へ",
  ぼ: "ほ",
  ぱ: "は",
  ぴ: "ひ",
  ぷ: "ふ",
  ぺ: "へ",
  ぽ: "ほ",
  っ: "",
  ー: ""
};

let overlayRefs = null;
let storageListenerBound = false;
let launcherTopPx = 180;

function normalize(text) {
  return (text || "")
    .toString()
    .toLowerCase()
    .replace(/[\s\-_:/\\|()\[\]{}]+/g, " ")
    .trim();
}

function toHalfWidth(text) {
  return String(text || "")
    .normalize("NFKC")
    .replace(/[\uFF01-\uFF5E]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) - 0xfee0))
    .replace(/\u3000/g, " ");
}

function extractDigits(text) {
  return toHalfWidth(text).replace(/\D/g, "");
}

function splitEmailAddress(email) {
  const normalized = toHalfWidth(email).trim();
  const atIndex = normalized.indexOf("@");
  if (atIndex < 0) return [normalized, ""];
  return [normalized.slice(0, atIndex), normalized.slice(atIndex + 1)];
}

function normalizeUniversityKey(text) {
  return toHalfWidth(String(text || ""))
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, "");
}

function getMatchedUniversityOverrides(universityText) {
  const key = normalizeUniversityKey(universityText);
  if (!key) return [];
  return UNIVERSITY_READING_OVERRIDES.filter((override) =>
    override.keywords.some((keyword) => {
      const keywordKey = normalizeUniversityKey(keyword);
      return keywordKey && (key.includes(keywordKey) || keywordKey.includes(key));
    })
  );
}

async function sendRuntimeMessage(message) {
  if (globalThis.browser?.runtime) {
    return extensionApi.runtime.sendMessage(message);
  }

  return new Promise((resolve, reject) => {
    extensionApi.runtime.sendMessage(message, (response) => {
      const err = globalThis.chrome?.runtime?.lastError;
      if (err) {
        reject(new Error(String(err.message || err)));
        return;
      }
      resolve(response);
    });
  });
}

function cleanProfileValue(value) {
  return String(value || "").trim();
}

function detectContactSubtype(field, text) {
  const source = normalize(toHalfWidth(text || ""));
  if (field === "email") {
    if (/(携帯|mobile|keitai|スマホ)/.test(source)) return "email_mobile";
    if (/(pc|パソコン|e mail|email|メール|mail)/.test(source)) return "email_pc";
    return "email_unknown";
  }

  if (field === "phone") {
    if (/(携帯|mobile|cell|スマホ)/.test(source)) return "phone_mobile";
    if (/(固定|自宅|landline|home|電話番号|tel|phone)/.test(source)) return "phone_landline";
    return "phone_unknown";
  }

  return "";
}

function resolveEmailValueForSubtype(subtype, profile) {
  const primary = cleanProfileValue(profile.email);
  const mobile = cleanProfileValue(profile.mobileEmail);
  if (subtype === "email_mobile") return mobile;
  if (subtype === "email_pc") return primary || mobile;
  return primary || mobile;
}

function resolvePhoneValueForSubtype(subtype, profile) {
  const primary = cleanProfileValue(profile.phone);
  if (!primary) return "";
  return primary;
}

function isVisible(el) {
  if (!(el instanceof HTMLElement)) return false;
  const style = getComputedStyle(el);
  if (style.visibility === "hidden" || style.display === "none") return false;
  const rect = el.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}

function isJqTransformHiddenSelect(el) {
  if (!(el instanceof HTMLSelectElement)) return false;
  const cls = String(el.className || "");
  if (/jqTransformHidden/i.test(cls)) return true;
  const style = getComputedStyle(el);
  return style.display === "none" && !!el.parentElement?.querySelector(".jqTransformSelectWrapper");
}

function isJqTransformHiddenChoice(el) {
  if (!(el instanceof HTMLInputElement)) return false;
  if (!["radio", "checkbox"].includes(String(el.type || "").toLowerCase())) return false;
  const cls = String(el.className || "");
  if (!/jqTransformHidden/i.test(cls)) return false;
  const parent = el.parentElement;
  if (!parent) return false;
  return parent.classList.contains("jqTransformRadioWrapper") || parent.classList.contains("jqTransformCheckboxWrapper");
}

function getJqTransformWrapper(el) {
  if (!(el instanceof HTMLSelectElement)) return null;
  const direct = el.closest(".jqTransformSelectWrapper");
  if (direct instanceof HTMLElement) return direct;

  const parent = el.parentElement;
  if (!parent) return null;

  if (parent.classList?.contains("jqTransformSelectWrapper")) return parent;

  const wrappers = Array.from(parent.querySelectorAll(".jqTransformSelectWrapper")).filter((node) => node instanceof HTMLElement);
  if (!wrappers.length) return null;
  const prev = el.previousElementSibling;
  if (prev instanceof HTMLElement && prev.classList.contains("jqTransformSelectWrapper")) return prev;
  return wrappers[0] || null;
}

function getLayoutElement(el) {
  if (el instanceof HTMLSelectElement && isJqTransformHiddenSelect(el)) {
    const wrapper = getJqTransformWrapper(el);
    if (wrapper) return wrapper;
  }
  return el;
}

function collectStructuredTextHints(el) {
  const hints = [];
  const pushIfText = (value) => {
    const text = String(value || "").trim();
    if (text) hints.push(text);
  };

  const cell = el.closest("td, th");
  if (cell?.previousElementSibling) pushIfText(cell.previousElementSibling.textContent);

  const tr = el.closest("tr");
  if (tr) {
    const firstCell = Array.from(tr.children).find((node) => node instanceof HTMLElement && /^(TH|TD)$/.test(node.tagName));
    if (firstCell) pushIfText(firstCell.textContent);
  }

  const dd = el.closest("dd");
  if (dd) {
    const dt = dd.previousElementSibling;
    if (dt?.tagName === "DT") pushIfText(dt.textContent);
  }

  const localContainerSelectors = ["[class*='form-row']", "[class*='form-group']", "[class*='field']", "[class*='item']", "fieldset", "li"];
  for (const selector of localContainerSelectors) {
    const container = el.closest(selector);
    if (!container) continue;
    const labelLike = container.querySelector(":scope > label, :scope > legend, :scope > th, :scope > dt, :scope > .label, :scope > .title");
    if (labelLike) pushIfText(labelLike.textContent);
    break;
  }

  if (el.parentElement?.previousElementSibling) pushIfText(el.parentElement.previousElementSibling.textContent);

  return hints;
}

function getTextMeta(el) {
  const parts = [
    el.id,
    el.name,
    el.placeholder,
    el.autocomplete,
    el.getAttribute("aria-label"),
    el.getAttribute("data-testid"),
    el.getAttribute("data-qa"),
    el.className
  ];

  if (el.labels?.length) {
    for (const lbl of el.labels) parts.push(lbl.textContent);
  }

  const labelledBy = el.getAttribute("aria-labelledby");
  if (labelledBy) {
    labelledBy.split(/\s+/).forEach((id) => {
      const node = document.getElementById(id);
      if (node?.textContent) parts.push(node.textContent);
    });
  }

  parts.push(...collectStructuredTextHints(el));

  return normalize(parts.filter(Boolean).join(" "));
}

function getRawHintText(el) {
  const parts = [
    el.id,
    el.name,
    el.placeholder,
    el.getAttribute("aria-label"),
    el.getAttribute("title"),
    el.getAttribute("pattern")
  ];

  if (el.labels?.length) {
    for (const lbl of el.labels) parts.push(lbl.textContent);
  }

  const labelledBy = el.getAttribute("aria-labelledby");
  if (labelledBy) {
    labelledBy.split(/\s+/).forEach((id) => {
      const node = document.getElementById(id);
      if (node?.textContent) parts.push(node.textContent);
    });
  }

  parts.push(...collectStructuredTextHints(el));

  return parts.filter(Boolean).join(" ");
}

function detectNamePart(meta) {
  if (!meta) return null;

  if (
    /(建物名|会社名|学校名|大学名|病院名|商品名|地名|町名|部署名|ユーザー名|サイト名|件名|署名|宛名|希望名|通称|ニックネーム|建物|部屋|号室)/.test(
      meta
    ) &&
    !/(family.?name|last.?name|given.?name|first.?name|surname|姓名|氏名)/.test(meta)
  ) {
    return null;
  }

  const hasStandaloneSei = /(?:^|\s)姓(?:$|\s|[（(])/u.test(meta) || /(?:^|\s)名字(?:$|\s|[（(])/u.test(meta);
  const hasStandaloneMei = /(?:^|\s)名(?:$|\s|[（(])/u.test(meta);
  const hasNameContext = /(name|family|given|first|last|surname|full.?name|氏名|姓名|お名前|姓|名)/.test(meta);
  if (!hasNameContext) return null;

  if (/(company|organization|school|faculty|大学|会社|企業|団体|学校|学部)/.test(meta) && !/(姓|名|first|last|given|family|surname)/.test(meta)) {
    return null;
  }

  if (/(family.?name|last.?name|surname)/.test(meta) || hasStandaloneSei) return "last";
  if (/(given.?name|first.?name)/.test(meta) || hasStandaloneMei) return "first";
  return null;
}

function detectNameScriptHint(meta) {
  if (!meta) return "unknown";
  if (/(western.?script|roman|latin|alphabet|english|英字|英語|ローマ字)/.test(meta)) return "roman";
  if (/(hiragana|ひらがな)/.test(meta)) return "hiragana";
  if (/(katakana|カタカナ|全角.?カナ)/.test(meta)) return "katakana";
  if (/(furigana|kana|かな|カナ|ふりがな|フリガナ|phonetic)/.test(meta)) return "kana";
  if (/(kanji|漢字)/.test(meta)) return "kanji";
  return "unknown";
}

function chooseUnknownScript(partCandidates) {
  const hasExplicitKanji = partCandidates.some((x) => x.scriptHint === "kanji");
  const hasExplicitKana = partCandidates.some((x) => KANA_SCRIPT_KEYS.has(x.scriptHint));

  for (const candidate of partCandidates) {
    if (candidate.scriptHint !== "unknown") continue;

    if (hasExplicitKanji && !hasExplicitKana) {
      candidate.scriptHint = "kana";
      continue;
    }

    if (hasExplicitKana && !hasExplicitKanji) {
      candidate.scriptHint = "kanji";
      continue;
    }

    candidate.scriptHint = "kanji";
  }
}

function mapNameCandidate(candidate) {
  if (!candidate.namePart || !candidate.scriptHint) return;

  if (candidate.scriptHint === "roman") {
    candidate.field = candidate.namePart === "last" ? "lastNameEnglish" : "firstNameEnglish";
    return;
  }

  if (candidate.namePart === "last") {
    if (candidate.scriptHint === "kanji") {
      candidate.field = "lastNameKanji";
      return;
    }

    if (candidate.scriptHint === "hiragana") {
      candidate.field = "lastNameKana";
      candidate.kanaTarget = "hiragana";
      return;
    }

    if (candidate.scriptHint === "katakana") {
      candidate.field = "lastNameKana";
      candidate.kanaTarget = "katakana";
      return;
    }

    candidate.field = "lastNameKana";
    return;
  }

  if (candidate.namePart === "first") {
    if (candidate.scriptHint === "kanji") {
      candidate.field = "firstNameKanji";
      return;
    }

    if (candidate.scriptHint === "hiragana") {
      candidate.field = "firstNameKana";
      candidate.kanaTarget = "hiragana";
      return;
    }

    if (candidate.scriptHint === "katakana") {
      candidate.field = "firstNameKana";
      candidate.kanaTarget = "katakana";
      return;
    }

    candidate.field = "firstNameKana";
  }
}

function assignNameFields(candidates) {
  const grouped = { last: [], first: [] };

  for (const candidate of candidates) {
    if (!(candidate.el instanceof HTMLInputElement || candidate.el instanceof HTMLTextAreaElement)) continue;
    if (candidate.el instanceof HTMLInputElement) {
      const inputType = String(candidate.el.type || "").toLowerCase();
      if (["hidden", "radio", "checkbox"].includes(inputType)) continue;
    }

    const part = detectNamePart(candidate.meta);
    if (!part) continue;

    candidate.namePart = part;
    candidate.scriptHint = detectNameScriptHint(candidate.meta);
    grouped[part].push(candidate);
  }

  chooseUnknownScript(grouped.last);
  chooseUnknownScript(grouped.first);

  for (const candidate of grouped.last) mapNameCandidate(candidate);
  for (const candidate of grouped.first) mapNameCandidate(candidate);
}

function assignNameFieldsByPairRows(candidates) {
  const unresolved = candidates.filter((candidate) => {
    if (candidate.field) return false;
    if (!(candidate.el instanceof HTMLElement)) return false;
    if (!candidate.el.matches("input, textarea, [role='combobox']")) return false;
    const type = String(candidate.el.type || "").toLowerCase();
    return !["hidden", "checkbox", "radio"].includes(type);
  });

  const rowLike = unresolved.filter((candidate) => /(氏名|姓名|お名前|漢字氏名|カナ氏名|フリガナ氏名|name)/.test(candidate.meta));
  const rows = buildLineGroups(rowLike, 24);

  for (const row of rows) {
    const rowCandidates = row.map((item) => item.candidate).filter((candidate) => !candidate.field);
    if (rowCandidates.length < 2) continue;

    const combinedMeta = rowCandidates.map((candidate) => candidate.meta).join(" ");
    const sorted = [...rowCandidates].sort(
      (a, b) => (a.layoutEl || a.el).getBoundingClientRect().left - (b.layoutEl || b.el).getBoundingClientRect().left
    );

    let targetFields = null;
    if (/(漢字氏名|氏名.*漢字|漢字)/.test(combinedMeta)) {
      targetFields = ["lastNameKanji", "firstNameKanji"];
    } else if (/(カナ氏名|フリガナ|ふりがな|かな氏名|カナ|かな)/.test(combinedMeta)) {
      targetFields = ["lastNameKana", "firstNameKana"];
    } else if (/(english|英字|ローマ字|roman|latin)/.test(combinedMeta)) {
      targetFields = ["lastNameEnglish", "firstNameEnglish"];
    }

    if (!targetFields) continue;
    sorted[0].field = targetFields[0];
    sorted[1].field = targetFields[1];

    if (targetFields[0] === "lastNameKana") {
      const kanaTarget = /(hiragana|ひらがな)/.test(combinedMeta)
        ? "hiragana"
        : /(katakana|カタカナ)/.test(combinedMeta)
          ? "katakana"
          : null;
      if (kanaTarget) {
        sorted[0].kanaTarget = kanaTarget;
        sorted[1].kanaTarget = kanaTarget;
      }
    }
  }
}

function matchNonNameField(meta, type, el) {
  const name = normalize(toHalfWidth(el?.getAttribute?.("name") || el?.name || ""));
  const id = normalize(toHalfWidth(el?.id || ""));
  const autocomplete = normalize(toHalfWidth(el?.getAttribute?.("autocomplete") || ""));
  const keyed = `${name} ${id} ${autocomplete}`;
  const keyId = `${name} ${id}`;

  // HTML autocomplete tokens are the most reliable cross-site signal.
  if (/\bpostal(?:\s|-)?code\b|\bzip\b/.test(autocomplete)) return "postalCode";
  if (/\baddress(?:\s|-)?level1\b/.test(autocomplete)) return "prefecture";
  if (/\baddress(?:\s|-)?level2\b/.test(autocomplete)) return "city";
  if (/\baddress(?:\s|-)?line1\b/.test(autocomplete)) return "addressLine1";
  if (/\baddress(?:\s|-)?line2\b/.test(autocomplete)) return "addressLine2";

  if (/\bgkbn\b/.test(keyed)) return "educationType";
  if (/\bgon\b/.test(keyed)) return "universityKanaInitial";
  if (/\bdken\b/.test(keyed)) return "universityPrefecture";
  if (/\bybirth\b|\bmbirth\b|\bdbirth\b/.test(keyed)) return "birthDate";
  if (/\bpostal\b|\bpost.?code\b|\bzip\b|郵便/.test(keyId)) return "postalCode";
  if (/\bcity\b|\bmunicipality\b|市区町村|市区郡/.test(keyId)) return "city";
  if (/\baddress.?line.?2\b|\baddress.?2\b|\bline.?2\b|\baddr.?2\b/.test(keyId)) return "addressLine2";
  if (/\baddress.?line.?1\b|\baddress.?1\b|\bline.?1\b|\baddr.?1\b/.test(keyId)) return "addressLine1";
  if (/\baddress\b/.test(keyId)) return "addressLine1";

  if (type === "email") return "email";
  if (type === "tel") return "phone";
  if (type === "url") return "portfolio";
  if (type === "password") return "password";

  for (const [field, patterns] of Object.entries(NON_NAME_FIELD_PATTERNS)) {
    if (patterns.some((pattern) => pattern.test(meta))) {
      const negatives = FIELD_NEGATIVE_PATTERNS[field];
      if (negatives?.some((pattern) => pattern.test(meta))) continue;
      return field;
    }
  }

  return null;
}

function katakanaToHiragana(value) {
  return String(value || "")
    .normalize("NFKC")
    .replace(/[\u30a1-\u30f6]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) - 0x60));
}

function hiraganaToKatakana(value) {
  return String(value || "")
    .normalize("NFKC")
    .replace(/[\u3041-\u3096]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) + 0x60));
}

function deriveGojuonInitial(text) {
  const hira = katakanaToHiragana(toHalfWidth(String(text || "")));
  for (const ch of hira) {
    if (!/[ぁ-ゖゔ]/.test(ch)) continue;
    const mapped = GOJUON_INITIAL_MAP[ch] ?? ch;
    if (!mapped) continue;
    if (/[あ-ん]/.test(mapped)) return mapped;
  }
  return "";
}

function deriveUniversityKanaInitial(profile) {
  const explicit = deriveGojuonInitial(profile.universityKanaInitial);
  if (explicit) return explicit;

  const university = cleanProfileValue(profile.university);
  if (!university) return "";

  const direct = deriveGojuonInitial(university);
  if (direct) return direct;

  for (const override of getMatchedUniversityOverrides(university)) {
    const initial = deriveGojuonInitial(override.reading);
    if (initial) return initial;
  }

  return "";
}

function splitPostalDigits(value) {
  const digits = extractDigits(value);
  return [digits.slice(0, 3), digits.slice(3, 7)];
}

function getDefaultPhoneLengths(digits) {
  if (digits.length === 11) return [3, 4, 4];
  if (digits.length === 10 && /^(03|06)/.test(digits)) return [2, 4, 4];
  if (digits.length === 10) return [3, 3, 4];
  if (digits.length === 9) return [2, 3, 4];
  return [3, 4, 4];
}

function splitDigitsByLengths(digits, partCount, explicitLengths = []) {
  const parts = [];
  let cursor = 0;

  for (let i = 0; i < partCount; i += 1) {
    if (i === partCount - 1) {
      parts.push(digits.slice(cursor));
      break;
    }

    let len = Number(explicitLengths[i]);
    if (!Number.isFinite(len) || len <= 0) {
      const remainingParts = partCount - i;
      len = Math.max(1, Math.floor((digits.length - cursor) / remainingParts));
    }

    parts.push(digits.slice(cursor, cursor + len));
    cursor += len;
  }

  return parts;
}

function splitPhoneDigits(value, partCount, explicitLengths = []) {
  const digits = extractDigits(value);
  if (!digits) return Array(partCount).fill("");
  if (partCount <= 1) return [digits];

  const hasExplicit = explicitLengths.some((x) => Number.isFinite(Number(x)) && Number(x) > 0);
  const defaultLengths = getDefaultPhoneLengths(digits);
  const lengths = hasExplicit ? explicitLengths : defaultLengths;

  return splitDigitsByLengths(digits, partCount, lengths);
}

function formatPhoneForSingleField(value) {
  const digits = extractDigits(value);
  if (digits.length <= 4) return digits;
  return splitPhoneDigits(digits, 3).filter(Boolean).join("-");
}

function formatPostalForSingleField(value) {
  const [a, b] = splitPostalDigits(value);
  return b ? `${a}-${b}` : a;
}

function parseBirthDate(value) {
  const normalized = toHalfWidth(value).trim();
  const matched = normalized.match(/(\d{4})\D+(\d{1,2})\D+(\d{1,2})/) || normalized.match(/^(\d{4})(\d{2})(\d{2})$/);
  if (!matched) return null;

  const year = matched[1];
  const monthNum = Number(matched[2]);
  const dayNum = Number(matched[3]);
  if (!Number.isFinite(monthNum) || !Number.isFinite(dayNum)) return null;

  return {
    year,
    month: String(monthNum).padStart(2, "0"),
    monthRaw: String(monthNum),
    day: String(dayNum).padStart(2, "0"),
    dayRaw: String(dayNum)
  };
}

function detectBirthPartHint(candidate) {
  const idName = normalize(`${candidate.el?.id || ""} ${candidate.el?.name || ""}`);
  if (/(^| )ybirth( |$)|birth.?year|(^| )year( |$)/i.test(idName)) return "year";
  if (/(^| )mbirth( |$)|birth.?month|(^| )month( |$)/i.test(idName)) return "month";
  if (/(^| )dbirth( |$)|birth.?day|(^| )day( |$)/i.test(idName)) return "day";

  const narrowHint = `${candidate.el?.placeholder || ""} ${candidate.el?.getAttribute("aria-label") || ""} ${
    candidate.el?.getAttribute("title") || ""
  }`;
  if (/(year|yyyy|yy)/i.test(narrowHint)) return "year";
  if (/(month|mm)/i.test(narrowHint)) return "month";
  if (/(day|dd)/i.test(narrowHint)) return "day";

  const hint = `${candidate.rawHint || ""} ${candidate.meta || ""}`;
  const hasYear = /(year|年|yyyy|yy|birth.?year)/i.test(hint);
  const hasMonth = /(month|月|mm|birth.?month)/i.test(hint);
  const hasDay = /(day|日|dd|birth.?day)/i.test(hint);
  const hits = Number(hasYear) + Number(hasMonth) + Number(hasDay);
  if (hits > 1) return "";
  if (hasYear) return "year";
  if (hasMonth) return "month";
  if (hasDay) return "day";
  return "";
}

function birthPartValues(part, parsed) {
  if (!parsed) return [];
  if (part === "year") return [parsed.year];
  if (part === "month") return [parsed.month, parsed.monthRaw];
  if (part === "day") return [parsed.day, parsed.dayRaw];
  return [];
}

function getExplicitSegmentLength(el) {
  const maxLen = Number(el.maxLength);
  if (Number.isFinite(maxLen) && maxLen > 0 && maxLen <= 8) return maxLen;

  const pattern = el.getAttribute("pattern") || "";
  const matched = pattern.match(/\{(\d+)\}/);
  if (matched) {
    const len = Number(matched[1]);
    if (Number.isFinite(len) && len > 0 && len <= 8) return len;
  }

  return 0;
}

function shouldHyphenatePhone(candidate) {
  const hint = `${candidate.rawHint || ""} ${candidate.meta || ""}`;
  if (/ハイフン不要|ハイフンなし|記号なし|without hyphen/i.test(hint)) return false;
  if (/ハイフン|半角記号|[-－ー]\d{2,4}[-－ー]\d{2,4}/.test(hint)) return true;
  const pattern = candidate.el.getAttribute("pattern") || "";
  return pattern.includes("-");
}

function shouldHyphenatePostal(candidate) {
  const hint = `${candidate.rawHint || ""} ${candidate.meta || ""}`;
  if (/ハイフン不要|ハイフンなし|記号なし|without hyphen/i.test(hint)) return false;
  if (/〒|郵便番号|ハイフン|[-－ー]\d{4}/.test(hint)) return true;
  const pattern = candidate.el.getAttribute("pattern") || "";
  return pattern.includes("-");
}

function resolveAutofillValue(candidate, profile) {
  const { field, kanaTarget } = candidate;
  let rawValue = profile[field];

  if (field === "email") {
    rawValue = resolveEmailValueForSubtype(candidate.contactSubtype || "email_unknown", profile);
  }

  if (field === "phone") {
    rawValue = resolvePhoneValueForSubtype(candidate.contactSubtype || "phone_unknown", profile);
  }

  if (field === "universityKanaInitial") {
    rawValue = rawValue || deriveUniversityKanaInitial(profile);
  }

  if (field === "addressLine1") {
    const line1 = cleanProfileValue(rawValue);
    if (!line1) return line1;

    const shouldCombineCity = Boolean(candidate.combineCityForAddressLine1);
    if (!shouldCombineCity) return line1;

    const city = cleanProfileValue(profile.city);
    if (!city) return line1;

    const cityNorm = normalize(toHalfWidth(city));
    const line1Norm = normalize(toHalfWidth(line1));
    if (line1Norm.startsWith(cityNorm)) return line1;
    return `${city}${line1}`;
  }

  if (rawValue == null || rawValue === "") return rawValue;

  if (field === "postalCode") {
    return shouldHyphenatePostal(candidate) ? formatPostalForSingleField(rawValue) : extractDigits(rawValue);
  }

  if (field === "phone") {
    return shouldHyphenatePhone(candidate) ? formatPhoneForSingleField(rawValue) : extractDigits(rawValue);
  }

  if (!KANA_FIELD_KEYS.has(field)) return rawValue;

  if (kanaTarget === "hiragana") return katakanaToHiragana(rawValue);
  if (kanaTarget === "katakana") return hiraganaToKatakana(rawValue);
  return rawValue;
}

function expandCandidateValues(field, value) {
  if (value == null || value === "") return [];

  if (field === "educationType") {
    const aliases = EDUCATION_TYPE_ALIASES[value] || [];
    return Array.from(new Set([String(value), ...aliases].map((x) => toHalfWidth(x).trim()).filter(Boolean)));
  }

  if (field === "universityKanaInitial") {
    const base = toHalfWidth(String(value)).trim();
    if (!base) return [];
    return Array.from(new Set([base, katakanaToHiragana(base), hiraganaToKatakana(base)]));
  }

  if (field === "birthDate") {
    const normalized = toHalfWidth(String(value)).trim();
    const numeric = String(Number(normalized));
    const values = [normalized];
    if (Number.isFinite(Number(normalized))) values.push(numeric);
    return Array.from(new Set(values.filter(Boolean)));
  }

  if (field !== "gender") return [String(value)];

  const aliasValues = GENDER_VALUE_ALIASES[value] || [];
  return [String(value), ...aliasValues];
}

function getInputLabelText(input) {
  const parts = [input.value, input.getAttribute("aria-label"), input.id, input.name];
  if (input.labels?.length) {
    for (const label of input.labels) parts.push(label.textContent);
  }
  const wrapper = input.closest("label");
  if (wrapper?.textContent) parts.push(wrapper.textContent);

  // jqTransform radio/checkbox often stores user-visible text in sibling labels.
  if (input.parentElement?.classList?.contains("jqTransformRadioWrapper") || input.parentElement?.classList?.contains("jqTransformCheckboxWrapper")) {
    const sibling = input.parentElement.nextElementSibling;
    if (sibling?.tagName === "LABEL" && sibling.textContent) {
      parts.push(sibling.textContent);
    }
  }

  const li = input.closest("li");
  if (li) {
    const labelLike = li.querySelector("label, .gojyuuon, .smallmar");
    if (labelLike?.textContent) parts.push(labelLike.textContent);
    const sectionHeading = li.closest(".formbox04, .formbox06")?.querySelector("h3, h4, .heading_l3, .heading_l4");
    if (sectionHeading?.textContent) parts.push(sectionHeading.textContent);
  }

  return normalize(parts.filter(Boolean).join(" "));
}

function getRadioChoiceLabel(input) {
  const parts = [];
  const push = (value) => {
    const text = String(value || "").trim();
    if (text) parts.push(text);
  };

  if (input.labels?.length) {
    for (const label of input.labels) push(label.textContent);
  }

  const wrapper = input.closest("label");
  if (wrapper) push(wrapper.textContent);

  const next = input.nextElementSibling;
  if (next?.tagName === "LABEL") push(next.textContent);

  if (input.parentElement?.classList?.contains("jqTransformRadioWrapper") || input.parentElement?.classList?.contains("jqTransformCheckboxWrapper")) {
    const sibling = input.parentElement.nextElementSibling;
    if (sibling?.tagName === "LABEL") push(sibling.textContent);
  }

  const li = input.closest("li");
  if (li) {
    const labelLike = li.querySelector("label, .gojyuuon, .smallmar");
    if (labelLike) push(labelLike.textContent);
  }

  push(input.value);

  const unique = Array.from(new Set(parts));
  if (!unique.length) return "";
  return unique.sort((a, b) => b.length - a.length)[0];
}

function getRadioShortKanaLabel(input) {
  const labels = [];
  const push = (value) => {
    const text = String(value || "").trim();
    if (text) labels.push(text);
  };

  if (input.labels?.length) {
    for (const label of input.labels) push(label.textContent);
  }
  const sibling = input.parentElement?.nextElementSibling;
  if (sibling?.tagName === "LABEL") push(sibling.textContent);
  const liLabel = input.closest("li")?.querySelector("label.gojyuuon");
  if (liLabel) push(liLabel.textContent);

  for (const text of labels) {
    const normalized = katakanaToHiragana(toHalfWidth(text)).trim();
    if (/^[ぁ-ん]$/.test(normalized)) return normalized;
  }
  return "";
}

function normalizeUniversityChoiceText(text) {
  return toHalfWidth(String(text || ""))
    .normalize("NFKC")
    .toLowerCase()
    .replace(/[()（）\[\]{}「」『』【】〈〉《》〔〕、。，,.・･'"]/g, "")
    .replace(/\s+/g, "")
    .replace(/ヶ/g, "ケ")
    .replace(/ヵ/g, "カ");
}

function buildUniversityChoiceCandidates(text) {
  const candidates = new Set();
  const prefixes = ["学校法人", "国立", "公立", "私立"];
  const suffixes = ["大学院大学", "高等専門学校", "短期大学", "専門学校", "大学院", "大学", "学園", "college", "university", "school"];

  const addCandidateVariants = (sourceText) => {
    const base = normalizeUniversityChoiceText(sourceText);
    if (!base) return;
    candidates.add(base);

    for (const prefix of prefixes) {
      const normalizedPrefix = normalizeUniversityChoiceText(prefix);
      if (base.startsWith(normalizedPrefix) && base.length > normalizedPrefix.length + 1) {
        candidates.add(base.slice(normalizedPrefix.length));
      }
    }

    const current = Array.from(candidates);
    for (const item of current) {
      for (const suffix of suffixes) {
        const normalizedSuffix = normalizeUniversityChoiceText(suffix);
        if (!normalizedSuffix) continue;
        if (item.endsWith(normalizedSuffix) && item.length > normalizedSuffix.length + 1) {
          candidates.add(item.slice(0, -normalizedSuffix.length));
        }
      }
    }
  };

  addCandidateVariants(text);
  for (const override of getMatchedUniversityOverrides(text)) {
    for (const keyword of override.keywords) {
      addCandidateVariants(keyword);
    }
  }

  return Array.from(candidates).filter((x) => x.length >= 2);
}

function isLikelyUniversityNameChoice(label) {
  const text = toHalfWidth(String(label || ""));
  if (!/(大学|短期大学|大学院大学|専門学校|college|university|school)/i.test(text)) return false;
  return normalizeUniversityChoiceText(text).length >= 4;
}

function normalizeKanaForMatch(text) {
  return normalize(katakanaToHiragana(toHalfWidth(String(text || ""))));
}

function setRadioValue(el, field, value, options = {}) {
  const { overwrite = true } = options;
  if (!overwrite && el.checked) return false;

  const targetCandidates = expandCandidateValues(field, value)
    .map((x) => normalize(x))
    .filter(Boolean);
  const targetKanaCandidates = targetCandidates.map((x) => normalizeKanaForMatch(x)).filter(Boolean);
  if (!targetCandidates.length && !targetKanaCandidates.length) return false;

  const escapedName = typeof CSS !== "undefined" && CSS.escape ? CSS.escape(el.name || "") : el.name || "";
  let radios = [];
  if (el.name) {
    radios = Array.from(document.querySelectorAll(`input[type="radio"][name="${escapedName}"]`));
  } else {
    radios = [el];
  }

  radios = radios.filter((radio) => !radio.disabled);
  if (!radios.length) return false;

  if (field === "universityKanaInitial") {
    const targetInitial = deriveGojuonInitial(value);
    if (targetInitial) {
      const byKanaLabel = radios.find((radio) => getRadioShortKanaLabel(radio) === targetInitial);
      if (byKanaLabel) {
        if (isJqTransformHiddenChoice(byKanaLabel)) {
          const proxy = byKanaLabel.parentElement?.querySelector("a.jqTransformRadio, a.jqTransformCheckbox");
          if (proxy instanceof HTMLElement) clickLikeUser(proxy);
        }
        clickLikeUser(byKanaLabel);
        byKanaLabel.checked = true;
        byKanaLabel.dispatchEvent(new Event("input", { bubbles: true }));
        byKanaLabel.dispatchEvent(new Event("change", { bubbles: true }));
        return true;
      }
    }
  }

  const exact = radios.find((radio) => {
    const meta = getInputLabelText(radio);
    const val = normalize(radio.value);
    const metaKana = normalizeKanaForMatch(meta);
    const valKana = normalizeKanaForMatch(radio.value);
    return (
      targetCandidates.some((target) => target === val || target === meta) ||
      targetKanaCandidates.some((target) => target === valKana || target === metaKana)
    );
  });

  const fuzzy = exact
    ? exact
    : radios.find((radio) => {
        const meta = getInputLabelText(radio);
        const val = normalize(radio.value);
        const metaKana = normalizeKanaForMatch(meta);
        const valKana = normalizeKanaForMatch(radio.value);
        const textMatch = targetCandidates.some((target) => meta.includes(target) || (val && (val.includes(target) || target.includes(val))));
        const kanaMatch = targetKanaCandidates.some(
          (target) =>
            metaKana.includes(target) ||
            (valKana && (valKana.includes(target) || target.includes(valKana)))
        );
        return textMatch || kanaMatch;
      });

  const matched = fuzzy;
  if (!matched) return false;

  if (isJqTransformHiddenChoice(matched)) {
    const proxy = matched.parentElement?.querySelector("a.jqTransformRadio, a.jqTransformCheckbox");
    if (proxy instanceof HTMLElement) clickLikeUser(proxy);
  }
  clickLikeUser(matched);
  matched.checked = true;
  matched.dispatchEvent(new Event("input", { bubbles: true }));
  matched.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

function fillUniversityChoiceGroups(profile, overwrite, handledElements) {
  const university = cleanProfileValue(profile.university);
  const targetCandidates = buildUniversityChoiceCandidates(university).filter((x) => x.length >= 3);
  if (!targetCandidates.length) return;

  const radios = Array.from(document.querySelectorAll("input[type='radio']")).filter(
    (el) => !el.disabled && (isVisible(el) || isJqTransformHiddenChoice(el))
  );
  const groups = new Map();
  for (const radio of radios) {
    if (!radio.name) continue;
    if (!groups.has(radio.name)) groups.set(radio.name, []);
    groups.get(radio.name).push(radio);
  }

  for (const group of groups.values()) {
    if (group.length < 2) continue;
    const checkedRadio = group.find((radio) => radio.checked) || null;

    const choices = group
      .map((radio) => {
        const label = getRadioChoiceLabel(radio);
        const normalized = buildUniversityChoiceCandidates(label);
        return { radio, label, normalized };
      })
      .filter((choice) => choice.normalized.length > 0);

    if (!choices.length) continue;

    const universityLikeCount = choices.filter((choice) => isLikelyUniversityNameChoice(choice.label)).length;
    if (universityLikeCount < 2) continue;

    let matched = choices.find((choice) => choice.normalized.some((candidate) => targetCandidates.includes(candidate)));

    if (!matched) {
      matched = choices.find((choice) =>
        choice.normalized.some(
          (candidate) =>
            candidate.length >= 4 &&
            targetCandidates.some((target) => target.length >= 4 && (candidate.includes(target) || target.includes(candidate)))
        )
      );
    }

    if (!matched) continue;

    if (checkedRadio) {
      const checkedChoice = choices.find((choice) => choice.radio === checkedRadio);
      if (checkedChoice) {
        const alreadyMatches =
          checkedChoice.normalized.some((candidate) => targetCandidates.includes(candidate)) ||
          checkedChoice.normalized.some(
            (candidate) =>
              candidate.length >= 4 &&
              targetCandidates.some((target) => target.length >= 4 && (candidate.includes(target) || target.includes(candidate)))
          );
        if (alreadyMatches) continue;
      }
      // Allow overriding default preselection when we found any confident match.
    }

    if (isJqTransformHiddenChoice(matched.radio)) {
      const proxy = matched.radio.parentElement?.querySelector("a.jqTransformRadio, a.jqTransformCheckbox");
      if (proxy instanceof HTMLElement) clickLikeUser(proxy);
    }
    clickLikeUser(matched.radio);
    matched.radio.checked = true;
    matched.radio.dispatchEvent(new Event("input", { bubbles: true }));
    matched.radio.dispatchEvent(new Event("change", { bubbles: true }));
    group.forEach((radio) => handledElements.add(radio));
  }
}

function chooseMatchingOption(options, candidates) {
  if (!options.length || !candidates.length) return null;

  const normalizedCandidates = candidates.map((x) => normalize(x)).filter(Boolean);

  for (const option of options) {
    const text = normalize(option.textContent || option.label || "");
    const val = normalize(option.value || "");
    if (normalizedCandidates.some((target) => target === text || target === val)) {
      return option;
    }
  }

  for (const option of options) {
    const text = normalize(option.textContent || option.label || "");
    const val = normalize(option.value || "");
    if (normalizedCandidates.some((target) => text.includes(target) || val.includes(target))) {
      return option;
    }
  }

  return null;
}

function clickLikeUser(el) {
  ["pointerdown", "mousedown", "mouseup", "click"].forEach((eventName) => {
    el.dispatchEvent(new MouseEvent(eventName, { bubbles: true, cancelable: true, view: window }));
  });
}

function selectFromCustomCombobox(el, field, value) {
  const candidates = expandCandidateValues(field, value);
  if (!candidates.length) return false;

  clickLikeUser(el);

  const ariaControls = el.getAttribute("aria-controls");
  const scoped = ariaControls ? document.getElementById(ariaControls) : null;
  const optionSelector = "[role='option'], [data-value], li";

  const nodes = (scoped || document)
    ? Array.from((scoped || document).querySelectorAll(optionSelector)).filter((node) => isVisible(node) && normalize(node.textContent).length > 0)
    : [];

  const matched = chooseMatchingOption(nodes, candidates);
  if (!matched) return false;

  clickLikeUser(matched);
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

function isCustomCombobox(el) {
  if (el.getAttribute("role") !== "combobox") return false;
  const tag = el.tagName;
  if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return false;
  return true;
}

function isSelectPlaceholder(el) {
  if (!(el instanceof HTMLSelectElement)) return false;
  const selectedIndex = el.selectedIndex;
  const selected = selectedIndex >= 0 ? el.options[selectedIndex] : null;
  const value = normalize(toHalfWidth(el.value || ""));
  const text = normalize(toHalfWidth(selected?.textContent || ""));
  const rawValue = toHalfWidth(el.value || "").trim();
  const rawText = toHalfWidth(selected?.textContent || "").trim();

  if (!value && !text) return true;
  if (selected?.disabled && !value) return true;
  if (selectedIndex === 0 && !value) return true;

  const placeholderTokens = [
    "-",
    "--",
    "---",
    "0",
    "選択",
    "選択してください",
    "未選択",
    "未設定",
    "choose",
    "select"
  ];

  if (placeholderTokens.some((token) => value === token || text === token)) return true;

  if (
    /選択|choose|select|未選択|未設定/.test(rawValue) ||
    /選択|choose|select|未選択|未設定/.test(rawText)
  ) {
    return true;
  }

  if (/^[\-ー－−▼▽]+$/.test(rawValue || rawText)) return true;

  // Some DOB dropdowns keep placeholder-like labels such as "月" or "日".
  if (selectedIndex === 0 && /^(年|月|日)$/.test(rawValue || rawText)) return true;

  return false;
}

function hasExistingValue(el) {
  if (el.tagName === "SELECT") return !isSelectPlaceholder(el);
  if (el instanceof HTMLInputElement) {
    const type = String(el.type || "").toLowerCase();
    if (type === "radio" || type === "checkbox") return el.checked;
    return el.value.trim() !== "";
  }
  if (el instanceof HTMLTextAreaElement) return el.value.trim() !== "";
  const text = normalize(el.textContent);
  return text !== "";
}

function setFieldValue(el, field, value, options = {}) {
  const { overwrite = true } = options;
  if (value == null || value === "") return false;
  if (!overwrite && hasExistingValue(el)) return false;

  if (el.tagName === "SELECT") {
    const option = chooseMatchingOption(Array.from(el.options), expandCandidateValues(field, value));
    if (!option) return false;
    el.value = option.value;

    if (isJqTransformHiddenSelect(el)) {
      const wrapper = getJqTransformWrapper(el);
      const label = wrapper?.querySelector("div > span, span");
      if (label) label.textContent = (option.textContent || option.label || "").trim();
    }
  } else if (isCustomCombobox(el)) {
    return selectFromCustomCombobox(el, field, value);
  } else if (el.type === "radio") {
    return setRadioValue(el, field, value, { overwrite });
  } else if (el.type === "checkbox") {
    return false;
  } else {
    el.focus();
    el.value = String(value);
  }

  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

function isFillable(el) {
  if (!(el instanceof HTMLElement)) return false;
  const allowHiddenSpecialSelect = el.tagName === "SELECT" && isJqTransformHiddenSelect(el);
  const allowHiddenSpecialChoice = isJqTransformHiddenChoice(el);
  if (!allowHiddenSpecialSelect && !allowHiddenSpecialChoice && !isVisible(el)) return false;
  if (el.matches("[disabled], [readonly], [type='hidden']")) return false;
  if (el.getAttribute("aria-hidden") === "true") return false;
  return el.matches("input, textarea, select, [role='combobox']");
}

function buildLineGroups(candidates, tolerance = 24) {
  const positioned = candidates
    .map((candidate) => {
      const target = candidate.layoutEl || candidate.el;
      return { candidate, rect: target.getBoundingClientRect() };
    })
    .sort((a, b) => a.rect.top - b.rect.top || a.rect.left - b.rect.left);

  const rows = [];
  for (const item of positioned) {
    const last = rows[rows.length - 1];
    if (!last || Math.abs(item.rect.top - last.top) > tolerance) {
      rows.push({ top: item.rect.top, items: [item] });
      continue;
    }
    last.items.push(item);
  }

  return rows.map((row) => row.items.sort((a, b) => a.rect.left - b.rect.left));
}

function findCommonAncestor(a, b) {
  const ancestors = new Set();
  let node = a;
  while (node) {
    ancestors.add(node);
    node = node.parentElement;
  }

  node = b;
  while (node) {
    if (ancestors.has(node)) return node;
    node = node.parentElement;
  }

  return null;
}

function detectRowContactSubtype(row, field) {
  if (!row?.length) return field === "email" ? "email_unknown" : "phone_unknown";
  const left = row[0]?.candidate?.el || null;
  const right = row[row.length - 1]?.candidate?.el || null;
  const common = left && right ? findCommonAncestor(left, right) : null;
  const rowText = row
    .map((item) => `${item.candidate.meta || ""} ${item.candidate.rawHint || ""}`)
    .join(" ");
  return detectContactSubtype(field, `${rowText} ${common?.textContent || ""}`);
}

function isLikelySplitEmailPair(left, right) {
  const gap = right.rect.left - left.rect.right;
  if (gap < -10 || gap > 240) return false;

  const hintMeta = `${left.candidate.meta} ${right.candidate.meta}`.toLowerCase();
  if (/(local|domain|前半|後半|ドメイン|ユーザー|アカウント)/.test(hintMeta)) return true;

  const common = findCommonAncestor(left.candidate.el, right.candidate.el);
  const rawText = common?.textContent || "";
  if (/@/.test(rawText)) return true;

  const leftMax = Number(left.candidate.el.maxLength);
  const rightMax = Number(right.candidate.el.maxLength);
  return (
    (Number.isFinite(leftMax) && leftMax > 0 && leftMax <= 80) ||
    (Number.isFinite(rightMax) && rightMax > 0 && rightMax <= 255)
  );
}

function fillSplitEmailFields(candidates, profile, overwrite, handledElements) {
  const emailCandidates = candidates.filter((x) => x.field === "email" && !handledElements.has(x.el));
  const rows = buildLineGroups(emailCandidates);

  for (const row of rows) {
    if (row.length < 2) continue;
    const subtype = detectRowContactSubtype(row, "email");
    const rowEmail = resolveEmailValueForSubtype(subtype, profile);
    const [localPart, domainPart] = splitEmailAddress(rowEmail);
    if (!localPart || !domainPart) continue;

    for (let i = 0; i < row.length - 1; i += 1) {
      const left = row[i];
      const right = row[i + 1];
      if (handledElements.has(left.candidate.el) || handledElements.has(right.candidate.el)) continue;
      if (!isLikelySplitEmailPair(left, right)) continue;

      const filledLeft = setFieldValue(left.candidate.el, "email", localPart, { overwrite });
      const filledRight = setFieldValue(right.candidate.el, "email", domainPart, { overwrite });
      if (filledLeft || filledRight) {
        handledElements.add(left.candidate.el);
        handledElements.add(right.candidate.el);
        i += 1;
      }
    }
  }
}

function fillSplitPhoneFields(candidates, profile, overwrite, handledElements) {
  const phoneCandidates = candidates.filter((x) => x.field === "phone" && !handledElements.has(x.el));
  const rows = buildLineGroups(phoneCandidates);
  const rowSubtypes = rows.map((row) => detectRowContactSubtype(row, "phone"));

  for (let rowIndex = 0; rowIndex < rows.length; rowIndex += 1) {
    const row = rows[rowIndex];
    if (row.length < 2) continue;

    const items = row.filter((x) => x.candidate.el.tagName !== "SELECT");
    if (items.length < 2) continue;

    const fields = items.map((x) => x.candidate.el);
    const explicitLengths = fields.map((el) => getExplicitSegmentLength(el));
    const common = findCommonAncestor(fields[0], fields[fields.length - 1]);
    const rowHint = common?.textContent || "";
    const hasSplitHint =
      fields.length >= 3 ||
      explicitLengths.some((len) => len > 0) ||
      /[-－ー]/.test(rowHint) ||
      /(市外局番|下4桁|上4桁|前半|後半|3桁|4桁|電話番号1|電話番号2|電話番号3)/.test(rowHint);
    if (!hasSplitHint) continue;

    const subtype = rowSubtypes[rowIndex] || "phone_unknown";
    const rowPhone = resolvePhoneValueForSubtype(subtype, profile);
    if (!rowPhone) continue;

    const segments = splitPhoneDigits(rowPhone, fields.length, explicitLengths);

    let changed = false;
    for (let i = 0; i < fields.length; i += 1) {
      if (!segments[i]) continue;
      if (setFieldValue(fields[i], "phone", segments[i], { overwrite })) changed = true;
    }

    if (changed) {
      fields.forEach((el) => handledElements.add(el));
    }
  }
}

function fillSplitPostalFields(candidates, profile, overwrite, handledElements) {
  if (!profile.postalCode) return;

  const postalCandidates = candidates.filter((x) => x.field === "postalCode" && !handledElements.has(x.el));
  const rows = buildLineGroups(postalCandidates);

  for (const row of rows) {
    if (row.length < 2) continue;
    const [a, b] = splitPostalDigits(profile.postalCode);
    if (!a || !b) continue;

    const first = row[0].candidate.el;
    const second = row[1].candidate.el;
    const firstLen = getExplicitSegmentLength(first);
    const secondLen = getExplicitSegmentLength(second);
    const common = findCommonAncestor(first, second);
    const rowHint = common?.textContent || "";
    const hasSplitHint =
      (firstLen === 3 && secondLen === 4) || /[-－ー]/.test(rowHint) || /(前半|後半|3桁|4桁)/.test(rowHint);
    if (!hasSplitHint) continue;

    const changedA = setFieldValue(first, "postalCode", a, { overwrite });
    const changedB = setFieldValue(second, "postalCode", b, { overwrite });
    if (changedA || changedB) {
      handledElements.add(first);
      handledElements.add(second);
    }
  }
}

function fillSplitBirthDateFields(candidates, profile, overwrite, handledElements) {
  const parsed = parseBirthDate(profile.birthDate);
  if (!parsed) return;

  const birthCandidates = candidates.filter((x) => x.field === "birthDate" && !handledElements.has(x.el));
  const rows = buildLineGroups(birthCandidates);

  for (const row of rows) {
    if (row.length < 2) continue;

    const rowCandidates = row.map((x) => x.candidate);
    const byPart = { year: [], month: [], day: [] };
    const unknown = [];

    for (const candidate of rowCandidates) {
      const hint = detectBirthPartHint(candidate);
      if (hint) {
        byPart[hint].push(candidate);
      } else {
        unknown.push(candidate);
      }
    }

    if (!byPart.year.length && !byPart.month.length && !byPart.day.length && rowCandidates.length < 3) {
      continue;
    }

    let changed = false;
    for (const part of ["year", "month", "day"]) {
      for (const candidate of byPart[part]) {
        const values = birthPartValues(part, parsed);
        const ok = values.some((value) => value && setFieldValue(candidate.el, "birthDate", value, { overwrite }));
        if (ok) {
          handledElements.add(candidate.el);
          changed = true;
        }
      }
    }

    const partOrder = ["year", "month", "day"];
    const missingParts = partOrder.filter((part) => byPart[part].length === 0);
    for (let i = 0; i < unknown.length && i < missingParts.length; i += 1) {
      const part = missingParts[i];
      const values = birthPartValues(part, parsed);
      const ok = values.some((value) => value && setFieldValue(unknown[i].el, "birthDate", value, { overwrite }));
      if (ok) {
        handledElements.add(unknown[i].el);
        changed = true;
      }
    }

    if (changed) {
      for (const candidate of rowCandidates) {
        if (hasExistingValue(candidate.el)) handledElements.add(candidate.el);
      }
    }
  }
}

function collectBirthCandidates() {
  const elements = Array.from(document.querySelectorAll("input, select, [role='combobox']")).filter(isFillable);
  return elements
    .map((el) => {
      const meta = getTextMeta(el);
      const rawHint = getRawHintText(el);
      const field = matchNonNameField(meta, (el.type || "").toLowerCase(), el);
      return { el, layoutEl: getLayoutElement(el), meta, rawHint, field };
    })
    .filter((candidate) => candidate.field === "birthDate");
}

function sleep(ms) {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

async function retrySplitBirthDateFields(profile, overwrite, handledElements) {
  const parsed = parseBirthDate(profile.birthDate);
  if (!parsed) return;

  const retryDelaysMs = [150, 300, 450];
  for (const delayMs of retryDelaysMs) {
    await sleep(delayMs);
    const birthCandidates = collectBirthCandidates();
    if (!birthCandidates.length) continue;
    fillSplitBirthDateFields(birthCandidates, profile, overwrite, handledElements);
  }
}

function fillGroupedFields(candidates, profile, overwrite, handledElements) {
  fillSplitBirthDateFields(candidates, profile, overwrite, handledElements);
  fillSplitEmailFields(candidates, profile, overwrite, handledElements);
  fillSplitPostalFields(candidates, profile, overwrite, handledElements);
  fillSplitPhoneFields(candidates, profile, overwrite, handledElements);
  fillUniversityChoiceGroups(profile, overwrite, handledElements);
}

async function getSettings() {
  const stored = await storageGet([STORAGE_KEY]);
  return stored[STORAGE_KEY] || { enabled: true, profile: {} };
}

function currentDomainKey() {
  return String(location.hostname || "").toLowerCase();
}

async function getOverlayDomainStateMap() {
  const stored = await storageGet([OVERLAY_DOMAIN_STATE_KEY]);
  return stored[OVERLAY_DOMAIN_STATE_KEY] || {};
}

async function getOverlayStateForCurrentDomain() {
  const map = await getOverlayDomainStateMap();
  return map[currentDomainKey()] || { visible: false };
}

async function updateOverlayStateForCurrentDomain(patch) {
  const domain = currentDomainKey();
  if (!domain) return;
  const map = await getOverlayDomainStateMap();
  const current = map[domain] || {};
  map[domain] = { ...current, ...patch };
  await storageSet({ [OVERLAY_DOMAIN_STATE_KEY]: map });
}

function joinNonEmpty(parts, separator = " ") {
  return parts
    .map((x) => String(x || "").trim())
    .filter(Boolean)
    .join(separator);
}

function buildProfileSections(profile = {}) {
  return [
    {
      title: "基本情報",
      items: [
        { label: "氏名(漢字)", value: joinNonEmpty([profile.lastNameKanji, profile.firstNameKanji]) },
        { label: "氏名(フリガナ)", value: joinNonEmpty([profile.lastNameKana, profile.firstNameKana]) },
        { label: "氏名(English)", value: joinNonEmpty([profile.lastNameEnglish, profile.firstNameEnglish]) },
        { label: "希望名", value: profile.preferredName },
        { label: "メール(PC)", value: profile.email },
        { label: "メール(携帯)", value: profile.mobileEmail },
        { label: "電話番号", value: profile.phone },
        { label: "生年月日", value: profile.birthDate },
        { label: "性別", value: profile.gender }
      ]
    },
    {
      title: "住所",
      items: [
        { label: "郵便番号", value: formatPostalForSingleField(profile.postalCode) || profile.postalCode },
        { label: "都道府県", value: profile.prefecture },
        { label: "市区町村", value: profile.city },
        { label: "住所", value: profile.addressLine1 },
        { label: "建物名・部屋番号", value: profile.addressLine2 }
      ]
    },
    {
      title: "学歴",
      items: [
        { label: "学校区分", value: EDUCATION_TYPE_LABELS[profile.educationType] || profile.educationType },
        { label: "大学", value: profile.university },
        { label: "学校名頭文字", value: profile.universityKanaInitial },
        { label: "学校所在地", value: profile.universityPrefecture },
        { label: "学部/専攻", value: profile.faculty },
        { label: "卒業年", value: profile.graduationYear }
      ]
    },
    {
      title: "職歴・リンク",
      items: [
        { label: "勤務先", value: profile.company },
        { label: "LinkedIn", value: profile.linkedIn },
        { label: "GitHub", value: profile.github },
        { label: "Portfolio", value: profile.portfolio },
        { label: "自己PR", value: profile.note }
      ]
    }
  ];
}

async function copyTextToClipboard(text) {
  const payload = String(text || "");
  if (!payload) return false;

  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(payload);
      return true;
    }
  } catch (_err) {
    // Fallback below.
  }

  const ta = document.createElement("textarea");
  ta.value = payload;
  ta.setAttribute("readonly", "");
  ta.style.position = "fixed";
  ta.style.opacity = "0";
  ta.style.pointerEvents = "none";
  document.body.appendChild(ta);
  ta.select();
  const ok = document.execCommand("copy");
  document.body.removeChild(ta);
  return ok;
}

function flashCopiedElement(el) {
  if (!(el instanceof HTMLElement)) return;
  el.classList.add("is-copied");
  window.clearTimeout(el.__copiedTimerId);
  el.__copiedTimerId = window.setTimeout(() => {
    el.classList.remove("is-copied");
  }, 900);
}

function setOverlayStatus(message) {
  if (!overlayRefs?.status) return;
  overlayRefs.status.textContent = message;
  window.clearTimeout(overlayRefs.statusTimer);
  overlayRefs.statusTimer = window.setTimeout(() => {
    if (overlayRefs?.status) overlayRefs.status.textContent = "";
  }, 2200);
}

function setOverlayOpen(open) {
  if (!overlayRefs?.root) return;
  overlayRefs.root.classList.toggle("is-open", open);
}

async function setLauncherVisible(visible, options = {}) {
  const { persist = false } = options;
  if (!overlayRefs?.root) return;
  overlayRefs.root.classList.toggle("launcher-visible", visible);
  if (!visible) {
    setOverlayOpen(false);
  }
  if (persist) {
    await updateOverlayStateForCurrentDomain({ visible });
  }
}

function clampLauncherTop(topPx) {
  const minTop = 12;
  const maxTop = Math.max(minTop, window.innerHeight - 72);
  return Math.max(minTop, Math.min(maxTop, Math.round(topPx)));
}

function applyLauncherTop() {
  if (!overlayRefs?.launcherWrap) return;
  launcherTopPx = clampLauncherTop(launcherTopPx);
  overlayRefs.launcherWrap.style.top = `${launcherTopPx}px`;
}

function createProfileCopyCard(item) {
  const card = document.createElement("div");
  card.className = "mg-copy";

  const fullButton = document.createElement("button");
  fullButton.type = "button";
  fullButton.className = "mg-copy-full";

  const label = document.createElement("span");
  label.className = "mg-copy-label";
  label.textContent = item.label;

  const value = document.createElement("span");
  value.className = "mg-copy-value";
  value.textContent = item.value ? String(item.value) : "未設定";

  fullButton.append(label, value);
  card.append(fullButton);

  if (!item.value) {
    fullButton.disabled = true;
    card.classList.add("is-empty");
  } else {
    fullButton.addEventListener("click", async () => {
      const ok = await copyTextToClipboard(item.value);
      if (ok) flashCopiedElement(fullButton);
      setOverlayStatus(ok ? `${item.label} をコピーしました` : "コピーに失敗しました");
    });
  }

  return card;
}

function renderOverlayProfile(profile = {}) {
  if (!overlayRefs?.sections) return;
  overlayRefs.sections.innerHTML = "";

  for (const section of buildProfileSections(profile)) {
    const sectionEl = document.createElement("section");
    sectionEl.className = "mg-section";

    const title = document.createElement("h3");
    title.className = "mg-section-title";
    title.textContent = section.title;
    sectionEl.appendChild(title);

    const grid = document.createElement("div");
    grid.className = "mg-grid";
    for (const item of section.items) {
      grid.appendChild(createProfileCopyCard(item));
    }
    sectionEl.appendChild(grid);
    overlayRefs.sections.appendChild(sectionEl);
  }
}

function ensureInPageOverlay() {
  if (window !== window.top || !document.body) return null;
  if (overlayRefs) return overlayRefs;

  let host = document.getElementById(OVERLAY_HOST_ID);
  if (!host) {
    host = document.createElement("div");
    host.id = OVERLAY_HOST_ID;
    document.body.appendChild(host);
  }

  const shadow = host.shadowRoot || host.attachShadow({ mode: "open" });
  shadow.innerHTML = `
    <style>
      .mg-root { position: fixed; inset: 0; pointer-events: none; z-index: 2147483646; font-family: "Roboto", -apple-system, BlinkMacSystemFont, "Segoe UI", "Hiragino Sans", "Yu Gothic UI", "Yu Gothic", sans-serif; }
      .mg-panel { pointer-events: auto; position: fixed; top: 12px; right: 12px; width: min(420px, calc(100vw - 28px)); height: calc(100vh - 24px); background: linear-gradient(180deg, #f6fbff 0%, #edf6ff 100%); border: 1px solid #d8e9f9; border-radius: 16px; box-shadow: -12px 0 24px rgba(67, 126, 178, 0.22); transform: translateX(calc(100% + 18px)); transition: transform .2s ease; display: flex; flex-direction: column; overflow: hidden; }
      .mg-root.is-open .mg-panel { transform: translateX(0); }
      .mg-launcher-wrap { display: none; pointer-events: auto; position: fixed; right: 12px; width: 56px; height: 56px; }
      .mg-root.launcher-visible .mg-launcher-wrap { display: block; }
      .mg-root.is-open .mg-launcher-wrap { opacity: 0; transform: translateX(8px); pointer-events: none; transition: opacity .15s ease, transform .15s ease; }
      .mg-launcher { width: 56px; height: 56px; border: 1px solid #c8e2fa; border-radius: 14px; background: linear-gradient(120deg, #5ba8e8 0%, #3c91d8 100%); color: #fff; font-size: 30px; font-weight: 800; line-height: 1; cursor: grab; box-shadow: 0 10px 22px rgba(73, 143, 200, 0.34); }
      .mg-launcher:active { cursor: grabbing; }
      .mg-launcher-hide { position: absolute; top: -8px; left: -8px; width: 22px; height: 22px; border: none; border-radius: 999px; background: #315a7f; color: #fff; font-size: 13px; font-weight: 700; cursor: pointer; opacity: 0; transform: scale(.9); transition: opacity .12s ease, transform .12s ease; }
      .mg-launcher-wrap:hover .mg-launcher-hide { opacity: 1; transform: scale(1); }
      .mg-header { display: flex; align-items: center; justify-content: space-between; padding: 14px 14px 10px; border-bottom: 1px solid #d8e9f9; background: #ffffff; }
      .mg-title { margin: 0; font-size: 24px; font-weight: 800; color: #1c3551; letter-spacing: -0.01em; }
      .mg-header-actions { display: flex; gap: 8px; }
      .mg-icon-btn { border: 1px solid #c8e2fa; background: #edf7ff; border-radius: 8px; width: 30px; height: 30px; cursor: pointer; color: #2d6fa8; font-weight: 700; }
      .mg-actions { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; padding: 12px 14px 0; }
      .mg-btn { border: 1px solid #c8e2fa; border-radius: 12px; padding: 10px 12px; cursor: pointer; font-weight: 700; color: #fff; background: linear-gradient(120deg, #5ba8e8 0%, #3c91d8 100%); box-shadow: 0 8px 16px rgba(73, 143, 200, 0.24); }
      .mg-btn.secondary { background: #edf7ff; color: #2d6fa8; border: 1px solid #c8e2fa; box-shadow: none; }
      .mg-help { margin: 10px 14px 0; color: #5d7896; font-size: 13px; }
      .mg-status { min-height: 1.4em; margin: 6px 14px 0; color: #3f6387; font-size: 12px; font-weight: 700; }
      .mg-sections { overflow: auto; padding: 12px 14px 16px; display: grid; gap: 12px; }
      .mg-section { background: #ffffff; border: 1px solid #d8e9f9; border-radius: 12px; padding: 10px; box-shadow: 0 8px 20px rgba(72, 131, 182, 0.08); }
      .mg-section-title { margin: 2px 2px 10px; font-size: 14px; color: #1c3551; font-weight: 700; }
      .mg-grid { display: grid; gap: 8px; }
      .mg-copy { text-align: left; border: 1px solid #d8e9f9; border-radius: 10px; background: #f8fcff; padding: 8px 10px; display: grid; gap: 6px; }
      .mg-copy:hover { border-color: #d8e9f9; background: #f8fcff; }
      .mg-copy.is-empty { opacity: 0.7; background: #f2f8ff; }
      .mg-copy-full { text-align: left; border: none; background: transparent; padding: 0; margin: 0; cursor: pointer; display: grid; gap: 4px; }
      .mg-copy-full:disabled { cursor: default; }
      .mg-copy-full.is-copied .mg-copy-value { background: #dcefff; border-radius: 4px; padding: 1px 4px; }
      .mg-copy-label { font-size: 12px; color: #5d7896; font-weight: 700; }
      .mg-copy-value { font-size: 13px; color: #1c3551; white-space: pre-wrap; word-break: break-word; line-height: 1.42; display: inline; width: fit-content; box-decoration-break: clone; -webkit-box-decoration-break: clone; border-radius: 4px; background-color: rgba(199, 236, 255, 0); transition: background-color .72s cubic-bezier(0.22, 1, 0.36, 1); }
      .mg-copy-full:not(:disabled):hover .mg-copy-value { background-color: rgba(199, 236, 255, 0.95); transition-delay: .12s; }
      .mg-copy-full:not(:disabled):not(:hover) .mg-copy-value { transition-delay: .04s; }
    </style>
    <div class="mg-root">
      <div class="mg-launcher-wrap" data-role="launcher-wrap">
        <button class="mg-launcher" type="button" title="Open Magulify">M</button>
        <button class="mg-launcher-hide" type="button" data-role="hide-launcher" title="Hide">×</button>
      </div>
      <aside class="mg-panel" aria-label="Magulify Profile Panel">
        <header class="mg-header">
          <h2 class="mg-title">Magulify Profile</h2>
          <div class="mg-header-actions">
            <button class="mg-icon-btn" type="button" data-role="close" title="Close">×</button>
          </div>
        </header>
        <div class="mg-actions">
          <button class="mg-btn" type="button" data-role="autofill">Autofill Now</button>
          <button class="mg-btn secondary" type="button" data-role="refresh">Refresh</button>
          <button class="mg-btn secondary" type="button" data-role="edit">Edit</button>
        </div>
        <p class="mg-help">Click any block of text below to copy it.</p>
        <p class="mg-status" data-role="status"></p>
        <div class="mg-sections" data-role="sections"></div>
      </aside>
    </div>
  `;

  const root = shadow.querySelector(".mg-root");
  const launcherWrap = shadow.querySelector("[data-role='launcher-wrap']");
  const launcher = shadow.querySelector(".mg-launcher");
  const hideLauncherBtn = shadow.querySelector("[data-role='hide-launcher']");
  const closeBtn = shadow.querySelector("[data-role='close']");
  const refreshBtn = shadow.querySelector("[data-role='refresh']");
  const autofillBtn = shadow.querySelector("[data-role='autofill']");
  const editBtn = shadow.querySelector("[data-role='edit']");
  const status = shadow.querySelector("[data-role='status']");
  const sections = shadow.querySelector("[data-role='sections']");

  let suppressLauncherClick = false;
  launcher.addEventListener("click", (event) => {
    if (suppressLauncherClick) {
      suppressLauncherClick = false;
      event.preventDefault();
      return;
    }
    setOverlayOpen(true);
  });
  hideLauncherBtn.addEventListener("click", (event) => {
    event.stopPropagation();
    setLauncherVisible(false, { persist: true }).catch(() => {});
  });
  closeBtn.addEventListener("click", () => setOverlayOpen(false));

  refreshBtn.addEventListener("click", async () => {
    const settings = await getSettings();
    renderOverlayProfile(settings.profile || {});
    setOverlayStatus("プロフィールを更新しました");
  });

  autofillBtn.addEventListener("click", async () => {
    const result = await autofill({ overwrite: true });
    setOverlayStatus(`${result.filled || 0} 項目を入力しました`);
  });

  editBtn.addEventListener("click", async () => {
    try {
      const response = await sendRuntimeMessage({ type: "OPEN_OPTIONS_PAGE" });
      if (!response?.ok) {
        await openOptionsPage();
      }
      setOverlayStatus("設定ページを開きました");
    } catch (_err) {
      try {
        await openOptionsPage();
        setOverlayStatus("設定ページを開きました");
      } catch (_err2) {
        setOverlayStatus("設定ページを開けませんでした");
      }
    }
  });

  let dragging = false;
  let dragOffset = 0;
  let dragStartY = 0;

  launcher.addEventListener("pointerdown", (event) => {
    dragging = true;
    suppressLauncherClick = false;
    dragStartY = event.clientY;
    dragOffset = event.clientY - launcherTopPx;
    launcher.setPointerCapture?.(event.pointerId);
  });

  launcher.addEventListener("pointermove", (event) => {
    if (!dragging) return;
    if (Math.abs(event.clientY - dragStartY) > 4) suppressLauncherClick = true;
    launcherTopPx = clampLauncherTop(event.clientY - dragOffset);
    applyLauncherTop();
  });

  const endDrag = (event) => {
    if (!dragging) return;
    dragging = false;
    launcher.releasePointerCapture?.(event.pointerId);
    updateOverlayStateForCurrentDomain({ top: launcherTopPx }).catch(() => {});
  };

  launcher.addEventListener("pointerup", endDrag);
  launcher.addEventListener("pointercancel", endDrag);
  window.addEventListener("resize", applyLauncherTop);

  overlayRefs = {
    host,
    shadow,
    root,
    launcherWrap,
    launcher,
    hideLauncherBtn,
    closeBtn,
    refreshBtn,
    autofillBtn,
    editBtn,
    status,
    sections,
    statusTimer: null,
    resizeHandler: applyLauncherTop
  };
  applyLauncherTop();

  return overlayRefs;
}

async function refreshInPageOverlay() {
  const refs = ensureInPageOverlay();
  if (!refs) return;
  const settings = await getSettings();
  renderOverlayProfile(settings.profile || {});
}

function bindInPageOverlayStorageListener() {
  if (storageListenerBound) return;
  extensionApi.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "sync" && areaName !== "local") return;
    const changed = changes[STORAGE_KEY];
    if (!changed || !overlayRefs) return;
    renderOverlayProfile(changed.newValue?.profile || {});
  });
  storageListenerBound = true;
}

async function initInPageOverlay(options = {}) {
  const { showLauncher = false, persist = false } = options;
  if (window !== window.top || !document.body) return;
  ensureInPageOverlay();
  bindInPageOverlayStorageListener();
  await refreshInPageOverlay();
  await setLauncherVisible(showLauncher, { persist });
  setOverlayOpen(false);
}

async function autofill(options = {}) {
  const { overwrite = true } = options;
  const settings = await getSettings();
  if (!settings.enabled) {
    return { filled: 0, reason: "disabled" };
  }

  const profile = settings.profile || {};
  const inputs = Array.from(document.querySelectorAll("input, textarea, select, [role='combobox']")).filter(isFillable);

  const candidates = inputs.map((el) => {
    const meta = getTextMeta(el);
    const rawHint = getRawHintText(el);
    return {
      el,
      layoutEl: getLayoutElement(el),
      meta,
      rawHint,
      field: null,
      contactSubtype: null,
      kanaTarget: null,
      namePart: null,
      scriptHint: null,
      combineCityForAddressLine1: false
    };
  });

  assignNameFields(candidates);
  assignNameFieldsByPairRows(candidates);

  for (const candidate of candidates) {
    if (candidate.field !== null && candidate.field !== undefined) continue;
    candidate.field = matchNonNameField(candidate.meta, (candidate.el.type || "").toLowerCase(), candidate.el);
  }

  const hasCityFieldCandidate = candidates.some((candidate) => candidate.field === "city");
  for (const candidate of candidates) {
    if (candidate.field !== "addressLine1") continue;
    if (hasCityFieldCandidate) continue;

    const hint = `${candidate.meta || ""} ${candidate.rawHint || ""}`;
    const wantsTownOrFullAddress =
      /(町名以降|市区町村以降|番地と住所|住所.*以降|住所|address|street|丁目|番地)/.test(hint) &&
      !/(建物|マンション|アパート|部屋|号室|address.?line.?2|address.?2)/.test(hint);

    if (wantsTownOrFullAddress) {
      candidate.combineCityForAddressLine1 = true;
    }
  }

  for (const candidate of candidates) {
    if (candidate.field === "email" || candidate.field === "phone") {
      const text = `${candidate.meta || ""} ${candidate.rawHint || ""}`;
      candidate.contactSubtype = detectContactSubtype(candidate.field, text);
    }
  }

  const handledElements = new Set();
  fillGroupedFields(candidates, profile, overwrite, handledElements);
  await retrySplitBirthDateFields(profile, overwrite, handledElements);

  let filled = 0;
  for (const candidate of candidates) {
    const { el, field } = candidate;
    if (handledElements.has(el)) continue;
    if (!field) continue;
    const value = resolveAutofillValue(candidate, profile);
    if (setFieldValue(el, field, value, { overwrite })) filled += 1;
  }

  return { filled };
}

function debounce(fn, waitMs) {
  let timeoutId = null;
  return (...args) => {
    window.clearTimeout(timeoutId);
    timeoutId = window.setTimeout(() => fn(...args), waitMs);
  };
}

function startAutoRun() {
  const trigger = debounce(() => {
    autofill({ overwrite: false }).catch(() => {});
  }, AUTO_RUN_DEBOUNCE_MS);

  trigger();

  const observer = new MutationObserver(() => trigger());
  observer.observe(document.documentElement, { childList: true, subtree: true });
  window.setTimeout(() => observer.disconnect(), AUTO_RUN_OBSERVE_MS);
}

async function maybeShowLauncherFromDomainState() {
  if (window !== window.top) return;
  const state = await getOverlayStateForCurrentDomain();
  if (!state?.visible) return;
  if (Number.isFinite(Number(state.top))) {
    launcherTopPx = clampLauncherTop(Number(state.top));
  }
  await initInPageOverlay({ showLauncher: true, persist: false });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", startAutoRun, { once: true });
  document.addEventListener(
    "DOMContentLoaded",
    () => {
      maybeShowLauncherFromDomainState().catch(() => {});
    },
    { once: true }
  );
} else {
  startAutoRun();
  maybeShowLauncherFromDomainState().catch(() => {});
}

extensionApi.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "MAGULIFY_SHOW_LAUNCHER") {
    getOverlayStateForCurrentDomain()
      .then((state) => {
        if (Number.isFinite(Number(state?.top))) {
          launcherTopPx = clampLauncherTop(Number(state.top));
        }
        return initInPageOverlay({ showLauncher: true, persist: true });
      })
      .then(() => sendResponse({ ok: true }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (msg?.type !== "AUTOFILL_NOW") return;

  autofill({ overwrite: true })
    .then((result) => sendResponse({ ok: true, result }))
    .catch((err) => sendResponse({ ok: false, error: String(err) }));

  return true;
});
