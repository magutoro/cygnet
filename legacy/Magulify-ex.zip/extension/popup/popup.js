const { storageGet, storageSet, queryTabs, sendMessage, openOptionsPage } =
  globalThis.ExtensionApiCompat || {};
const extensionApi = globalThis.browser ?? globalThis.chrome;

if (!storageGet || !storageSet || !queryTabs || !sendMessage || !openOptionsPage) {
  throw new Error("Extension API compatibility helpers are not available.");
}

const STORAGE_KEY = "settings";

async function loadSettings() {
  const { settings } = await storageGet([STORAGE_KEY]);
  return settings || { enabled: true, profile: {} };
}

async function saveSettings(settings) {
  await storageSet({ [STORAGE_KEY]: settings });
}

function setStatus(text) {
  document.getElementById("status").textContent = text;
}

function isUnsupportedTabUrl(url) {
  const raw = String(url || "").trim().toLowerCase();
  if (!raw) return true;
  if (
    raw.startsWith("chrome://") ||
    raw.startsWith("edge://") ||
    raw.startsWith("about:") ||
    raw.startsWith("view-source:") ||
    raw.startsWith("devtools://") ||
    raw.startsWith("chrome-extension://") ||
    raw.startsWith("moz-extension://")
  ) {
    return true;
  }
  if (raw.includes("chromewebstore.google.com") || raw.includes("chrome.google.com/webstore")) {
    return true;
  }
  return false;
}

async function executeScriptCompat(details) {
  if (!extensionApi?.scripting?.executeScript) return;
  if (globalThis.browser?.scripting) {
    await extensionApi.scripting.executeScript(details);
    return;
  }
  await new Promise((resolve, reject) => {
    extensionApi.scripting.executeScript(details, () => {
      const err = globalThis.chrome?.runtime?.lastError;
      if (err) {
        reject(new Error(String(err.message || err)));
        return;
      }
      resolve();
    });
  });
}

async function ensureContentReady(tab) {
  if (!tab?.id) throw new Error("No active tab");
  if (isUnsupportedTabUrl(tab.url)) throw new Error("Unsupported page");

  try {
    await sendMessage(tab.id, { type: "MAGULIFY_SHOW_LAUNCHER" });
    return;
  } catch (_err) {
    await executeScriptCompat({
      target: { tabId: tab.id },
      files: ["src/extension-api-compat.js", "src/content.js"]
    });
    await sendMessage(tab.id, { type: "MAGULIFY_SHOW_LAUNCHER" });
  }
}

async function init() {
  const enabledInput = document.getElementById("enabled");
  const fillNowBtn = document.getElementById("fillNow");
  const openOptionsBtn = document.getElementById("openOptions");

  const [activeTab] = await queryTabs({ active: true, currentWindow: true });
  if (activeTab?.id) {
    try {
      await ensureContentReady(activeTab);
    } catch (_err) {
      // Silent during popup open.
    }
  }

  const settings = await loadSettings();
  enabledInput.checked = settings.enabled !== false;

  enabledInput.addEventListener("change", async () => {
    const next = { ...settings, enabled: enabledInput.checked };
    await saveSettings(next);
    setStatus(enabledInput.checked ? "Autofill ON" : "Autofill OFF");
  });

  fillNowBtn.addEventListener("click", async () => {
    const [tab] = await queryTabs({ active: true, currentWindow: true });
    if (!tab?.id) return;

    try {
      await ensureContentReady(tab);
      const response = await sendMessage(tab.id, { type: "AUTOFILL_NOW" });
      if (!response?.ok) {
        setStatus("入力に失敗しました");
        return;
      }

      const filled = response.result?.filled || 0;
      setStatus(`${filled}項目を入力`);
    } catch (_err) {
      setStatus("このページでは実行できません");
    }
  });

  openOptionsBtn.addEventListener("click", async () => {
    await openOptionsPage();
  });
}

init();
